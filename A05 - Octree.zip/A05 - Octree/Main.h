/*----------------------------------------------
Programmer: tec1850 (tec1850@rit.edu)
Date: 2019/04
----------------------------------------------*/
#ifndef __MAIN_H_
#define __MAIN_H_

#include "AppClass.h"

#endif //__MAIN_H_

/*
USAGE:
ARGUMENTS: ---
OUTPUT: ---
*/